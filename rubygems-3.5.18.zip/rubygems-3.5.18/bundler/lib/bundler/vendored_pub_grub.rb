# frozen_string_literal: true

module Bundler; end
require_relative "vendor/pub_grub/lib/pub_grub"
